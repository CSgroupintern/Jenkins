#!/bin/sh
# ** AUTO GENERATED **

# 3.5.1 - Ensure DCCP is disabled (Not Scored)

echo "install dccp /bin/true" >> /etc/modprobe.d/CIS.conf
