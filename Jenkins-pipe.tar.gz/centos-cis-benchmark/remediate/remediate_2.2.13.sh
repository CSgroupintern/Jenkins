#!/bin/sh
# ** AUTO GENERATED **

# 2.2.13 - Ensure HTTP Proxy Server is not enabled (Scored)

systemctl disable squid
