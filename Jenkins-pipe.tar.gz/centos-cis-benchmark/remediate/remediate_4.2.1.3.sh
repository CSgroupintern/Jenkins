#!/bin/sh
# ** AUTO GENERATED **

# 4.2.1.3 - Ensure rsyslog default file permissions configured (Scored)

echo "\$FileCreateMode 0640">>/etc/rsyslog.conf
