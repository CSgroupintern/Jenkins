#!/bin/sh
# ** AUTO GENERATED **

# 4.1.2 - Ensure auditd service is enabled (Scored)

chkconfig auditd on
