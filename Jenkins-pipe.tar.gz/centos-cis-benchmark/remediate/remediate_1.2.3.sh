#!/bin/sh
# ** AUTO GENERATED **

# 1.2.3 - Ensure gpgcheck is globally activated (Scored)

echo "gpgcheck=1" >> /etc/yum.repos.d/CIS.conf
