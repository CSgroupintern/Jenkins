#!/bin/sh
# ** AUTO GENERATED **

# 3.5.4 - Ensure TIPC is disabled (Not Scored)

echo "install tipc /bin/true" >> /etc/modprobe.d/CIS.conf
