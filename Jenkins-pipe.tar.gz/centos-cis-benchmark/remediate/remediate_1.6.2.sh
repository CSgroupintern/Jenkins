#!/bin/sh
# ** AUTO GENERATED **

# 1.6.2 - Ensure SELinux is installed (Scored)

yum install libselinux -y
