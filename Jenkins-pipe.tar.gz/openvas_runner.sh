# DevSecOps Project
# Author : Mathis Germa
# For CS Group
# June 2020


IPDEST=90.84.183.218
NAMET=gw1
PASSWDOMP=f15ea6df-2f32-4039-969d-656134c98327

# First configuration
RES1=$(omp -u admin -w $PASSWDOMP -X "<create_target><name>$NAMET</name><hosts>$IPDEST</hosts></create_target>")


RES1=$(omp --host=90.84.183.218 --port=31369 -u admin -w $PASSWDOMP -X "<create_target><name>$NAMET</name><hosts>$IPDEST</hosts></create_target>")

RES1=$(omp --host=90.84.183.218 --port=31369 -u admin -w $PASSWDOMP-X "<create_target><name>$NAMET</name><hosts>$IPDEST</hosts></create_target>")



# Withdraw id
if grep -q "id" $RES1; then
echo "Scan created"
ID=$(echo $RES1 | sed "s/ /\n/g" | grep id | sed 's/"/\n/g' | head -2 | tail -1)
## Get the type of scan with 
# omp -u admin -w $PASSWDOMP -g     

# Scan type lookup
SCANTYPE=$(omp -u admin -w $PASSWDOMP -g | grep "Full and very deep ultimate" | head -n1 | cut -d " " -f1)
# Parametering the scan
RES2=$(omp -u admin -w $PASSWDOMP -C -c $SCANTYPE --target=$ID --name "$NAMET")
# Launchng the scan
REPORTID=$(omp -u admin -w $PASSWDOMP -S $RES2)

# Wait
echo "Scan is performing..."
sleep 15

# Formatting and downloading the repoert
omp -u admin -w $PASSWDOMP --get-report $REPORTID --format c1645568-627a-11e3-a660-406186ea4fc5 > report.csv

else
echo "ERROR: Scan already exist"
fi

