cd /etc/kube-bench
sudo ./kube-bench node --benchmark cis-1.4 --json --outputfile /tmp/scans-jenkins-sec/logs_kube.json
cd /tmp/scans-jenkins-sec
python parser.py
