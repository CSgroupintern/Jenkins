#!/bin/sh
# ** AUTO GENERATED **

# 2.1.6 - Ensure tftp server is not enabled (Scored)

chkconfig tftp off 
