#!/bin/sh
# ** AUTO GENERATED **

# 3.4.2 - Ensure /etc/hosts.allow is configured (Scored)

# == you will need to manually review the /etc/hosts.allow file
exit 1
