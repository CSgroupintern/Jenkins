#!/bin/sh
# ** AUTO GENERATED **

# 1.6.1.5 - Ensure the MCS Translation Service (mcstrans) is not installed (Scored)

yum remove mcstrans -y 
