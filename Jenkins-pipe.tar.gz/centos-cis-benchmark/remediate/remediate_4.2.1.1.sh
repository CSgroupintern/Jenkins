#!/bin/sh
# ** AUTO GENERATED **

# 4.2.1.1 - Ensure rsyslog Service is enabled (Scored)

chkconfig rsyslog on
