#!/bin/sh
# ** AUTO GENERATED **

# 2.2.1.1 - Ensure time synchronization is in use (Not Scored)

yum install ntp -y
