#!/bin/sh
# ** AUTO GENERATED **

# 4.2.3 - Ensure rsyslog or syslog-ng is installed (Scored)

yum install rsyslog -y
