#!/bin/sh
# ** AUTO GENERATED **

# 3.5.3 - Ensure RDS is disabled (Not Scored)

echo "install rds /bin/true" >> /etc/modprobe.d/CIS.conf
