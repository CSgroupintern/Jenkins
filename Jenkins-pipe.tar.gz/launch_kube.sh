cd kube-bench/
sudo ./kube-bench node --benchmark cis-1.4 --json --outputfile logs.json
cd ..
python parser.py
