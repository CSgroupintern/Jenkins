#!/bin/sh
# ** AUTO GENERATED **

# 2.1.11 - Ensure xinetd is not enabled (Scored)

chkconfig xinetd off 
