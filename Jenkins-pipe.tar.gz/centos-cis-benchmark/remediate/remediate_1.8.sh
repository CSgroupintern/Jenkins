#!/bin/sh
# ** AUTO GENERATED **

# 1.8 - Ensure updates, patches, and additional security software are installed (Scored)

yum update -y --security
