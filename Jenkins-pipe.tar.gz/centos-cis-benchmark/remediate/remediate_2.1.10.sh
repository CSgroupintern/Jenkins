#!/bin/sh
# ** AUTO GENERATED **

# 2.1.10 - Ensure rsync service is not enabled (Scored)

chkconfig rsync off 
