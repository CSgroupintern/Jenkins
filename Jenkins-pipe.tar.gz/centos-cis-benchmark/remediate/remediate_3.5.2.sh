#!/bin/sh
# ** AUTO GENERATED **

# 3.5.2 - Ensure SCTP is disabled (Not Scored)

echo "install sctp /bin/true" >> /etc/modprobe.d/CIS.conf
