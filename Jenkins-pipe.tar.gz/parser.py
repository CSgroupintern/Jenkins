# DevSecOps Project
# Author : Mathis Germa
# For CS Group
# June 2020

import json

# loading the log file

with open('/tmp/scans-jenkins-sec/logs_kube.json') as json_file:
    data = json.load(json_file)

# Variables
n_pass = 0
n_warn = 0
n_info = 0
n_fail = 0

# Treatement
for elt in data['tests']:
    print("Analysing %s", elt['desc'])
    for result in elt['results']:
        if result['status'] == "PASS":
            n_pass+=1
        if result['status'] == "WARN":
            n_warn+=1
        if result['status'] == "INFO":
            n_info+=1
        if result['status'] == "FAIL":
            n_fail+=1



print("FAIL :")
print(n_fail)
print("WARN :")
print(n_warn)


