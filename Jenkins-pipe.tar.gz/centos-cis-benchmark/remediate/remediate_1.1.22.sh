#!/bin/sh
# ** AUTO GENERATED **

# 1.1.22 - Disable Automounting (Scored)

systemctl disable autofs
