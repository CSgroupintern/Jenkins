#!/bin/sh
# ** AUTO GENERATED **

# 5.5 - Ensure root login is restricted to system console (Not Scored)

cat /etc/securetty

exit 1
