#!/bin/sh
# ** AUTO GENERATED **

# 2.1.9 - Ensure tftp server is not enabled (Scored)

chkconfig tftp off 
