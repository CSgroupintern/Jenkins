#!/bin/sh
# ** AUTO GENERATED **

# 2.1.8 - Ensure telnet server is not enabled (Scored)

chkconfig telnet off 
